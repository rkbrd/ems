﻿using EMS.Model;

namespace EMS.BusinessLogicLayer
{
    public interface BLLInterface
    {
        Task CreateAsync(Info info);
        Task<List<Info>> GetAllAsync();
    }
}
