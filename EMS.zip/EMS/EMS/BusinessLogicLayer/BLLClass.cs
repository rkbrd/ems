﻿using EMS.DataAccessLayer;
using EMS.Model;

namespace EMS.BusinessLogicLayer
{
    public class BLLClass : BLLInterface
    {
        private readonly DALInterface _dalInterface;
        public BLLClass(DALInterface dalInterface)
        {
            _dalInterface = dalInterface;
        }

        public async Task CreateAsync(Info info)
        {
            await _dalInterface.CreateAsync(info);
            return;
        }

        public async Task<List<Info>> GetAllAsync()
        {
            return await _dalInterface.GetAllAsync();
        }
    }
}
