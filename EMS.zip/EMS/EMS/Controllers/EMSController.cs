﻿using EMS.BusinessLogicLayer;
using EMS.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EMS.Controllers
{
    [Route("api/[Action]")]
    [ApiController]
    public class EMSController : ControllerBase
    {
        private readonly BLLInterface _bllInterface;
        public EMSController(BLLInterface bllInterface)
        {
            _bllInterface = bllInterface;
        }

        [HttpGet]
        public async Task<List<Info>> GetAll()
        {
            return await _bllInterface.GetAllAsync();
        }

        [HttpPost]
        public async Task<IActionResult> Insert([FromBody]Info info)
        {
            try
            {
                await _bllInterface.CreateAsync(info);
                return CreatedAtAction(nameof(GetAll), info);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
