﻿namespace EMS.Model
{
    public class DBSettings
    {
        public string CollectionName { get; set; } = null!;
        public string ConnectionStrings { get; set; } = null!;
        public string DatabaseName { get; set; } = null!;
    }
}
