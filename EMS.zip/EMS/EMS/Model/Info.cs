﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;

namespace EMS.Model
{
    [BsonIgnoreExtraElements]
    public class Info
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("department")]
        public string Department { get; set; }

        [BsonElement("gender")]
        public string Gender { get; set; }

        [BsonElement("salary")]
        public string Salary { get; set; }
    }
}
