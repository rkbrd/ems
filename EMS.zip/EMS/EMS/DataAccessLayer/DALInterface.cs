﻿using EMS.Model;

namespace EMS.DataAccessLayer
{
    public interface DALInterface
    {
        Task CreateAsync(Info info);
        Task<List<Info>> GetAllAsync();
    }
}
