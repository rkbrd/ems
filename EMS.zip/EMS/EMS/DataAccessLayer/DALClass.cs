﻿using EMS.Model;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;

namespace EMS.DataAccessLayer
{
    public class DALClass : DALInterface
    {
        private readonly IMongoCollection<Info> _info;
        public DALClass(IOptions<DBSettings> dbSettings)
        {
            MongoClient client = new MongoClient(dbSettings.Value.ConnectionStrings);
            IMongoDatabase database = client.GetDatabase(dbSettings.Value.DatabaseName);
            _info = database.GetCollection<Info>(dbSettings.Value.CollectionName);
        }

        public async Task CreateAsync(Info info)
        {
            await _info.InsertOneAsync(info);
            return;
        }

        public async Task<List<Info>> GetAllAsync()
        {
            return await _info.Find(new BsonDocument()).ToListAsync();
        }
    }
}
